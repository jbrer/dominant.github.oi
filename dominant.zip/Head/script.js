// Добавление товара в корзину
document.querySelectorAll('.add-to-cart').forEach(button => {
	button.addEventListener('click', function () {
		alert('Товар добавлен в корзину!')
	})
})
